#!/bin/sh
cd /vpnserver
./vpncmd <<EOF
1


ListenerCreate
440
exit
EOF