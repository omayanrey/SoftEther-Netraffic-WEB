#!/bin/sh
cd /vpnserver
sed -i "/$1 /d" /vpnserver/count